package com.cat.Utils;

public enum EntityType {
    PLAYER,
    ENEMY,
    BULLET
}
